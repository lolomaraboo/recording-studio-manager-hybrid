# Public Landing Page & Marketing Site

Professional marketing website with product overview, feature showcase, pricing tiers, customer testimonials, demo videos, comparison with competitors, FAQ, blog, and lead capture forms. Optimized for SEO and conversion.

## Rationale
Currently no public-facing site to attract new customers or explain value proposition. Studios discovering the platform have no way to evaluate it before signing up. Transparent pricing and feature comparison addresses competitor pain points (Sonido hides pricing).

## User Stories
- As a studio owner researching solutions, I want to see transparent pricing and features so I can evaluate without sales calls
- As a decision-maker, I want to compare this platform with competitors so I understand the unique value proposition
- As a potential customer, I want to watch a demo video so I can see the product in action before committing time to a trial

## Acceptance Criteria
- [ ] Landing page with hero section explaining value proposition in one sentence
- [ ] Features page with screenshots showcasing key capabilities (booking, invoicing, AI, client portal)
- [ ] Pricing page with transparent tiers (Starter $29/mo, Pro $79/mo, Enterprise custom) and feature comparison matrix
- [ ] Customer testimonials section with quotes and logos from beta studios
- [ ] Demo video (2-3 min) showing end-to-end workflow from booking to invoice payment
- [ ] Competitor comparison page highlighting differentiators vs farmerswife, Sonido, generic tools
- [ ] FAQ addressing common objections (data security, migration from spreadsheets, onboarding time)
- [ ] Blog with SEO-optimized articles targeting 'studio management software', 'recording studio booking system' keywords
- [ ] Lead capture forms for demo requests and trial signups with email nurture sequence
- [ ] Mobile-responsive design with <3s page load time and 90+ Lighthouse score
